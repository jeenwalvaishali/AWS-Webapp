# webapp

# Technology Stack
  ### Programming Language: 
   * Node Js
  
# Prerequisite for App deployment  
* NPM
* Git
  
# Build Instruction

* Clone github repo using command "git clone".
* Run "npm install" in git bash terminal under git repo.


# Deploy Instruction
 
 * Run npm start


# Unit Testing
  
  * npm test