module.exports = {
  HOST: "localhost",
  USER: "root",
  //PASSWORD: "Mysqlvjneu@786",
  PASSWORD: "root",
  DB: "mysqluserdb"
};
